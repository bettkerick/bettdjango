from django.apps import AppConfig


class MovieLibConfig(AppConfig):
    name = 'movielib'
